This is an ultra large, A4 size piece of PCB Art.  At the time I was interested in creating something that had collectible parts that could be assembled into a frame.
Collect all the pieces and the whole thing would light up.  Each board has a piece of a large artwork on the front, and an amazing Australian
woman in STEM on the reverse.  Needless to say, the idea was scrapped.  I am still really proud of how the artwork turned out even if the concept was a flop. 
Enjoy. 
- Steph Piper
steph@piper3dp.com
makerqueen.com.au