The gerber files and working files for the 'Build An Open Future' MakerQueen Keyring. 
I've used the Eco.1 Layer for the purple soldermask, and the pink soldermask is the default.  Enjoy! 
- Steph Piper
steph@piper3dp.com
www.makerqueen.com.au